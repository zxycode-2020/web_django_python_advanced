from django.db import models


class Article(models.Model):
    title = models.CharField(max_length=128)
    date = models.DateTimeField(auto_now_add=True)
    content = models.TextField()

    def get_comments(self):
        comments = Comment.objects.filter(aid=self.id)
        return comments


class Comment(models.Model):
    aid = models.IntegerField(default=0)  # Article_id 做关联
    name = models.CharField(max_length=128)
    date = models.DateTimeField(auto_now_add=True)
    content = models.TextField()
