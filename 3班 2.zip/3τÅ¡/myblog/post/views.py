from math import ceil

from django.shortcuts import render, redirect

from post.models import Article, Comment
from post.common import print_ip
from post.middleware import R


@print_ip
def home(request):
    '''显示 home 页'''
    page = int(request.GET.get('page', 1)) - 1
    start = page * 5
    end = (page + 1) * 5
    articles = Article.objects.all()[start:end]

    pages = ceil(Article.objects.count() / 5)

    return render(request, 'home.html',
                  {'articles': articles, 'pages': range(1, pages + 1), 'count': R.get('IP_COUNT')})


@print_ip
def show(request):
    aid = int(request.GET.get('aid', 0))
    article = change(R.get('ARTICLE-%s' % aid))
    if article is None:
        article = Article.objects.get(id=aid)
        R.set('ARTICLE-%s' % aid, article)

    comments = article.get_comments()
    return render(request, 'detail.html',
                  {'article': article, 'comments': comments, 'count': R.get('IP_COUNT')})


@print_ip
def edit(request):
    if request.method == 'POST':
        aid = int(request.POST.get('aid', 0))
        article = Article.objects.get(id=aid)

        title = request.POST.get('title', '')
        content = request.POST.get('content', '')

        article.title = title
        article.content = content
        article.save()
        return redirect('/post/show/?aid=%d' % aid)
    else:
        aid = int(request.GET.get('aid', 0))
        article = Article.objects.get(id=aid)
        return render(request, 'edit.html', {'article': article, 'count': R.get('IP_COUNT')})


@print_ip
def search(request):
    keyword = request.POST.get('keyword', '')
    result = Article.objects.filter(title__contains=keyword)
    return render(request, 'home.html', {'articles': result, 'count': R.get('IP_COUNT')})


@print_ip
def comment(request):
    aid = int(request.POST.get('aid', 0))
    name = request.POST.get('name', '')
    content = request.POST.get('comment', '')
    Comment.objects.create(aid=aid, name=name, content=content)
    return redirect('/post/show/?aid=%d' % aid)
