# coding: utf-8

# 命名空间查找顺序
# 当前 -> 上层 -> 上...上层 -> 全局命名空间 -> builtin -> 报错


def print_ip(func):
    def wrap(request, *args, **kwargs):
        ip = request.META['REMOTE_ADDR']
        print('当前 IP', ip)
        result = func(request, *args, **kwargs)
        return result
    return wrap
