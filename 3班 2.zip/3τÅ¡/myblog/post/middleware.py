from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import render
from redis import Redis

R = Redis('127.0.0.1', 6379)

# COUNT = 0
# IP_LIST = set()


class BlockIP(MiddlewareMixin):
    def is_block_ip(self, ip):
        # 取出IP最后一位
        last = int(ip.split('.')[-1])
        # 判断是否是偶数
        return last == 0

    def ip_counter(self, ip):
        # if ip not in IP_LIST:
        #     IP_LIST.add(ip)
        #     global COUNT
        #     COUNT += 1
        #     print('计数器', COUNT)

        if R.sadd('IP_LIST', ip):
            R.incr('IP_COUNT')

    def process_request(self, request):
        ip = request.META['REMOTE_ADDR']

        if self.is_block_ip(ip):
            return render(request, 'blockers.html')

        self.ip_counter(ip)
